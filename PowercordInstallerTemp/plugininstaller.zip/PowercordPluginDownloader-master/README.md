# PluginDownloader

This plugin lets you install a plugin from a URL, and adds a button to download the plugin

# NOTE
- If you are on macOS you'll most likely need to install `Command Line Developer Tools`. I'm not sure why but it seems to be  required
