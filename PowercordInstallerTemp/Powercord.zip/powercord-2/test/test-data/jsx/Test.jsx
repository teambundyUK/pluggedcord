const { React } = require('powercord/webpack');

class Test extends React.PureComponent {
  render () {
    return (
      <div>btw have i told you i use arch?</div>
    );
  }
}

module.exports = Test;
