---
name: Feature Request
about: Create a feature request
title: '[Feature Request]' 
labels: 'enhancement'
assignees: ''

---

**Describe the feature request**
A clear and concise description of what the feature is.

**What Plugin would it be for?**
Name of plugin if applicable

**Expected behavior**
A clear and concise description of what you expected to happen.
