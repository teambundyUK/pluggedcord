/**
 * Copyright (c) 2018-2020 aetheryx & Bowser65
 * All Rights Reserved. Licensed under the Porkord License
 * https://powercord.dev/porkord-license
 */

exports.getAppDir = async () => '/Applications/Discord Canary.app/Contents/Resources/app';
