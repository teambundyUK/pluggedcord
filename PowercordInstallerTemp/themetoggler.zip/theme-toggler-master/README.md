# Theme Toggler
Simple plugin for [Powercord](https://powercord.dev) that allows toggling themes.

## Installation
1. Go to your powercord plugins folder. Run `git clone https://github.com/redstonekasi/theme-toggler`
2. Restart discord or fetch missing plugins.